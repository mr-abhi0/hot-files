<!DOCTYPE html>
<html dir="ltr">

<meta http-equiv="content-type" content="text/html;charset=utf-8" />

<head>
    <style>
        .ac_footer {
            position: relative;
            text-align: center;
            overflow: hidden;
            padding: 50px 0;
            color: #A12000;
        }

        .ac_footer a {
            color: #A12000;
        }

        .ac_footer p {
            text-align: center;
        }

        img[height="1"],
        img[width="1"] {
            display: none !important;
        }
    </style>


    <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, minimal-ui" name="viewport" />
    <meta content="IE=edge" http-equiv="X-UA-Compatible" />
    <title> Hammer of Thor - World no. 1 to grow a productive penis </title>
    <link href="style.css" media="all" rel="stylesheet" type="text/css" />
</head>

<body class="page">
    <!--retarget-->

    <!--retarget-->

    <div class="page__wrapper js-wrapper">
        <div class="header">
            <div class="container">
                <div class="header__inner">
                    <div class="header__logo">
                        <div class="logo"> Hammer of Thor </div>
                    </div>
                    <div class="header__subtitle"> WORLD NO. 1 TO GROW A PRODUCTIVE
                        <span> PENIS </span>
                    </div>
                    <div class="header__title">
                        <div class="header__title-big"> Biggest,</div>
                        <span> Bigger Than Ever </span>
                    </div>
                    <div class="package__sale12"> free
                        <div class="package__text"> shipping </div>
                    </div>
                    <div class="header__right">
                        <div class="header__timer">
                            <div class="timer">
                                <div class="timer__title"> Time left until offer ends </div>
                                <div class="timer__items js-timer"></div>
                            </div>
                        </div>
                        <div class="header__package">
                            <div class="package">
                                <div class="package__sale-text">
                                    <div class="sale"> Order Now
                                        <span> and get </span>
                                    </div>
                                </div>
                                <div class="package__image-wrapper">
                                    <div class="package__sale"> 50%
                                        <div class="package__text"> Off </div>
                                    </div>
                                    <div class="package__image"></div>
                                    <!-- <div class="package__sale" style="  top: -35px; left:-35px; font-size: 0.9em;">
                                        <div class="package__text" style="font-size: 26px;
    margin-top: 1px;"> लिंग मसाज Oil
                                        </div>
                                        <img src="img/sticker.png" width="50px" alt="">
                                        <div class="package__text" style="font-size: 1.6em;"> फ्री
                                        </div>
                                    </div> -->
                                    <!-- <img class="package__sale" style=" width: 200px;  top: -35px; left:-55px; background: no-repeat; " src="img/sticker.png"  alt=""> -->
                                </div>
                            </div>
                        </div>
                        <div class="header__price">
                            <div class="price">
                                <div class="price__inner">
                                    <div class="price__items">
                                        <div class="price__items-old">
                                        </div>
                                        <div class="price__items-new"> Pack of 20 Capsules
                                        </div>
                                    </div>
                                    <div class="price__button">
                                        <div class="button js-scroll-to"> <a style="text-decoration:none; color:#fff;" href="javascript: scrollToForm();"> Order Now </a></div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--div class="price__items-new" ><a style="color:red;" href="tel:+91-8929013389">Call Now : 8929013389</a>
</div-->
                    </div>
                    <div class="header__advantages">
                        <div class="header-advantages">
                            <div class="header-advantages__item">
                                <div class="header-advantages__item-icon-wrapper">
                                    <div class="header-advantages__item-icon header-advantages__item-icon_increase">
                                    </div>
                                </div>
                                <div class="header-advantages__item-title"> lengthen penis

                                </div>
                            </div>
                            <div class="header-advantages__item">
                                <div class="header-advantages__item-icon-wrapper">
                                    <div class="header-advantages__item-icon header-advantages__item-icon_clock"></div>
                                </div>
                                <div class="header-advantages__item-title">
                                    <span> long lasting </span> sex
                                </div>
                            </div>
                            <div class="header-advantages__item">
                                <div class="header-advantages__item-icon-wrapper">
                                    <div class="header-advantages__item-icon header-advantages__item-icon_acute"></div>
                                </div>
                                <div class="header-advantages__item-title">
                                    <span> enhance </span> the senses
                                </div>
                            </div>
                            <div class="header-advantages__item">
                                <div class="header-advantages__item-icon-wrapper">
                                    <div class="header-advantages__item-icon header-advantages__item-icon_volume"></div>
                                </div>
                                <div class="header-advantages__item-title"> sexy size </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="page__content">
            <div class="s-increase">
                <div class="container">
                    <div class="s-increase__title">
                        <div class="s-increase__title-inner">
                            <div class="s-increase__title-top"> Real </div>
                            <div class="s-increase__title-bottom">
                                <span> Growth, up to 40% </span> increase
                                <span> in penis size </span>
                            </div>
                        </div>
                    </div>

                    <div class="s-increase__compare">
                        <div class="compare">
                            <div class="compare__items">
                                <div class="compare__item">
                                    <div class="compare-item compare-item_before">
                                        <div class="compare-item__information-wrapper compare-item__information-wrapper_before">
                                            <div class="compare-item__information compare-item__information_before">
                                                Both length and thickness increase after use.
                                                <span> Hammer of Thor </span> not only
                                                <span>increases the size</span>
                                                <span>but also the length.</span>
                                            </div>
                                        </div>
                                        <div class="compare-item__time-wrapper compare-item__time-wrapper_before">
                                            <div class="compare-item__time compare-item__time_before">
                                                <div class="compare-item__time-title"> Maximum standing time: </div>
                                                <div class="compare-item__time-value"> 10-15 minutes

                                                </div>
                                            </div>
                                        </div>
                                        <div class="compare-item__label compare-item__label_before"> Earlier </div>
                                        <div class="compare-item__length compare-item__length_before"> 14 cm </div>
                                        <div class="compare-item__width compare-item__width_before"> 3 cm </div>
                                    </div>
                                </div>
                                <div class="compare__item">
                                    <div class="compare-item compare-item_after">
                                        <div class="compare-item__information-wrapper compare-item__information-wrapper_after">
                                            <div class="compare-item__information compare-item__information_after"> The tissues of the penis
                                                <span>can withstand</span> more pressure, which increases the duration of intercourse by
                                                <span>2-3 times</span>
                                            </div>
                                        </div>
                                        <div class="compare-item__time-wrapper compare-item__time-wrapper_after">
                                            <div class="compare-item__time compare-item__time_after">
                                                <div class="compare-item__time-title"> Maximum standing time: </div>
                                                <div class="compare-item__time-value"> 40-75 minutes
                                                </div>
                                            </div>
                                        </div>
                                        <div class="compare-item__label compare-item__label_after"> After </div>
                                        <div class="compare-item__length compare-item__length_after"> 18 cm </div>
                                        <div class="compare-item__width compare-item__width_after"> 5.5 cm </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="s-experts">
                <div class="container">
                    <div class="s-experts__title-wrapper">
                        <div class="s-experts__title">
                            <!--div class="s-experts__title-top">  विशेषज्ञ की राय </div>
<div class="s-experts__title-bottom">  इसके बारे में 
              <span>   अभी   </span></div-->
                            <!--div class="price__items-new" ><a style="color:red;" href="tel:+91-8929013389">Call Now : 8929013389</a>
</div-->
                        </div>
                    </div>
                    <div class="s-experts__items">
                        <div class="experts">
                            <div class="experts__item">
                                <div class="experts__item-image-wrapper">
                                    <img alt="" class="experts__item-image" src="img/expert1.png" />
                                    <div class="experts__item-title">
                                        <div class="experts__item-name"> Ravi Purandare </div>
                                        <div class="experts__item-post"> sexologist </div>
                                    </div>
                                </div>
                                <div class="experts__item-text">
                                    <div class="experts__item-text-shadow"></div>
                                    <p> Very few people know about the official statistics because gender surgery is a very sensitive issue and people do not like to talk about it much. Every year 10,000 men in India increase the length and girth of their penis through operation. We have always been told that this poses a health hazard because the nerve fibers go deep into the cavities of the penis.If there is any damage to these cavities, many risks arise, such as loss of sensation, pain on standing and impotence. </p>
                                    <p> <span>Hammer of Thor</span> has no serious side-effects as compared to surgery . It induces the body to naturally store fat-tissues in the penis.
                                    </p>
                                </div>
                            </div>
                            <div class="experts__item">
                                <div class="experts__item-image-wrapper">
                                    <img alt="" class="experts__item-image" src="img/expert2.png" />
                                    <div class="experts__item-title">
                                        <div class="experts__item-name"> Manoj Trivedi </div>
                                        <div class="experts__item-post"> sexologist </div>
                                    </div>
                                </div>
                                <div class="experts__item-text">
                                    <div class="experts__item-text-shadow"></div>
                                    <p> The most sensitive part of the vagina is located at a depth of 2-3 cm. Generally everyone thinks that the length of the penis is more important for the pleasure of a woman, but it is not so. The thickness (size) of a man's penis is more important for a woman's pleasure. The thicker and harder your penis, the more satisfied your wife will be.
                                    </p>
                                    <p> Not only this, the thick penis increases the feeling manifold by stimulating the clitoris of the woman during sexual intercourse, due to which the effect of orgasm increases manifold.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="s-reviews">
                <div class="container">
                    <div class="s-reviews__title-wrapper">
                        <div class="s-reviews__title">
                            <div class="s-reviews__title-top"> People already </div>
                            <div class="s-reviews__title-bottom">
                                Have tried and seen <span> Hammer of Thor </span>
                            </div>
                        </div>
                    </div>
                    <div class="s-reviews__items">
                        <div class="reviews">
                            <div class="reviews__items">
                                <div class="reviews__item">
                                    <div class="reviews__item-image-wrapper">
                                        <img alt="" class="reviews__item-image" src="img/reviewer-anonim.png" />
                                    </div>
                                    <div class="reviews__item-text-wrapper">
                                        <div class="reviews__item-title-wrapper">
                                            <div class="reviews__item-name-wrapper">
                                                <div class="reviews__item-name"> MINDLESS </div>
                                                <div class="reviews__item-age"> 26 years </div>
                                            </div>
                                            <div class="reviews__item-title">
                                                <span>I have never been able to give full satisfaction to my wife </span>
                                            </div>
                                        </div>
                                        <div class="reviews__item-text"> And she was always annoyed about it too: she asked me to do something about it several times because my penis was too small! I used to be very sad and I thought about many types of remedies. Finally I liked
                                            <span>Hammer of Thor</span>. Now it's been 3 weeks since I used it,
                                            <span>and my penis has become much bigger</span> and my wife can feel it too. She asks me to have sex many times now.
                                        </div>
                                    </div>
                                </div>

                                <div class="reviews__item">
                                    <div class="reviews__item-image-wrapper">
                                        <img alt="" class="reviews__item-image" src="img/reviewer-anonim.png" />
                                    </div>
                                    <div class="reviews__item-text-wrapper">
                                        <div class="reviews__item-title-wrapper">
                                            <div class="reviews__item-name-wrapper">
                                                <div class="reviews__item-name"> Jitendra </div>
                                                <div class="reviews__item-age"> 36 years </div>
                                            </div>
                                            <div class="reviews__item-title">
                                                <span> WITHOUT HAMMER OF THOR THERE WAS NO FUN IN SEX, SEX LIFE BECAME BORING</span>
                                            </div>
                                        </div>
                                        <div class="reviews__item-text"> We have been married for 8 years and we were bored of having the same sex. After delivery anyway, women need a little longer penis. Then I tried
                                            <span>Hammer of Thor</span> to increase the fun and frenzy during sex. My wife says
                                            <span>she has finally felt my penis now.</span> Now we have sex several times a week.
                                            <span> I have ordered another package.</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="reviews__item">
                                    <div class="reviews__item-image-wrapper">
                                        <img alt="" class="reviews__item-image" src="img/reviewer2.png" />
                                    </div>
                                    <div class="reviews__item-text-wrapper">
                                        <div class="reviews__item-title-wrapper">
                                            <div class="reviews__item-name-wrapper">
                                                <div class="reviews__item-name"> Hardik </div>
                                                <div class="reviews__item-age"> 27 years </div>
                                            </div>
                                            <div class="reviews__item-title">
                                                <span> Best product that works
                                                </span>
                                            </div>
                                        </div>
                                        <div class="reviews__item-text"> I got married at the age of twenty and my wife was 25 then. This was my wife's second marriage so I was always in fear that I would not be able to satisfy her. I did a lot of research on the internet to see what experienced men do in this situation, and I came to the conclusion that it would be wiser to take
                                            <span>Hammer of Thor</span> So I asked my wife and she happily said yes!
                                        </diV>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer">
            <div class="container">
                <div class="footer__inner">
                    <div class="footer__title">
                        <div class="footer__title-top">
                            <div class="footer__title-top-left"> Give it to Your Partner </div>
                            <div class="footer__title-top-right"> Extreme Pleasure and Excitement </div>
                        </div>
                        <div class="footer__title-bottom"> WHAT SHE DESERVES </div>
                    </div>
                    <div class="footer__content">
                        <div class="footer__left">
                            <div class="footer__timer">
                                <div class="timer">
                                    <div class="timer__title"> Time left until offer ends </div>
                                    <div class="timer__items js-timer">
                                    </div>
                                </div>
                            </div>
                            <div class="footer__package">
                                <div class="package">
                                    <div class="package__sale-text">
                                        <div class="sale"> Order Now
                                            <span> and Get </span>
                                        </div>
                                    </div>
                                    <div class="package__image-wrapper">
                                        <div class="package__sale"> 50%
                                            <div class="package__text"> OFF </div>
                                        </div>
                                        <div class="package__image"></div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="footer__form " id="order">

                            <form name="frmContact" id="frmContact" method="post" action="" enctype="multipart/form-data">
                                <div class="form__rows">
                                    <div class="form__title"> Order Now </div>

                                    <div class="form__row">
                                        <input class="input" name="userName" id="userName" placeholder="नाम" type="text" value="" />
                                    </div>
                                    <div class="form__row">
                                        <input class="input only only_number" name="subject" id="subject" placeholder="फ़ोन " type="text" value="" />
                                    </div>
                                    <!--div class="form__row">
<input class="input only only_number" name="content" id="content" placeholder="पिनकोड" type="text" value=""/>
</div>
<div class="form__row">
<input class="input only only_number" name="userEmail" id="userEmail" placeholder="पूरा पता" type="text" value=""/>
</div-->
                                    <div class="form__row">
                                        <select class="form-control" class="input only only_number" name="baddress" id="baddress" placeholder="price" type="text" value="">
                                            <option value="Pack Of 20 Capsules">Pack Of 20 Capsules</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form__price">
                                    <div class="price">
                                        <div class="price__inner">
                                            <div class="price__items">
                                                <div class="price__items-old">
                                                </div>
                                                <div class="price__items-new"> Pack Of 20 Capsules
                                                </div>
                                            </div>

                                            <div class="price__button">
                                                <input class="button  button__text" type="submit" name="send" class="buttonIndex" value=" अभी ऑर्डर करें " />

                                                <div id="statusMessage">
                                                </div>
                                            </div>
                                            <?php
                                            if (!empty($message)) {
                                            ?>
                                                <p class='<?php echo $type; ?>Message'>
                                                    <?php
                                                    echo '<script language="javascript">';
                                                    echo 'window.location = "db.php";';
                                                    echo '</script>';
                                                    ?>
                                                </p>
                                            <?php
                                            }
                                            ?>

                                        </div>
                                    </div>
                                </div>
                                <input name="time_zone" type="hidden" value="3" />
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <template id="js-timer-html">
            <div class="timer__item"> {h10}{h1}</div>
            <div class="timer__item"> {m10}{m1}</div>
            <div class="timer__item"> {s10}{s1}</div>
        </template>


        <div class="ac_footer"><span>&copy; 2023 Copyright. All rights reserved.</span><br>
            <a href="" target="_blank">Privacy policy</a> | <a href="">Report</a>
            <p>The results may vary depending on your individual features </p>

        </div>

        <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
        <script type="text/javascript">
            function scrollToForm() {
                document.querySelector('#frmContact').scrollIntoView({
                    behavior: 'smooth'
                })
            }

            // function validateContactForm() {
            //     var valid = true;

            //     $(".info").html("");
            //     $(".input-field").css('border', '#e0dfdf 1px solid');
            //     var userName = $("#userName").val();
            //     var userEmail = $("#userEmail").val();
            //     var subject = $("#subject").val();
            //     var baddress = $("#baddress").val();
            //     var content = $("#content").val();

            //     if (userName == "") {
            //         $("#userName-info").html("Required.");
            //         $("#userName").css('border', '#e66262 1px solid');
            //         valid = false;
            //     }

            //     if (subject == "") {
            //         $("#subject-info").html("Required.");
            //         $("#subject").css('border', '#e66262 1px solid');
            //         valid = false;
            //     }

            //     if (baddress == "") {
            //         $("#baddress-info").html("Required.");
            //         $("#baddress").css('border', '#e66262 1px solid');
            //         valid = false;
            //     }

            //     return valid;
            // }
        </script>
</body>


</html>