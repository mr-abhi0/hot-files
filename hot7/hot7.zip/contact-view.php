<!DOCTYPE html>
<html lang="hi">

<head>
    <title>Hammers of thor| #1 Male Enhancement product</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <script src="assets/jquery.min.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="google" content="notranslate">
    <meta name="description" content="Male Enhancement product">




    <link type="text/css" href="assets/order_me.css" rel="stylesheet" media="all">
    <link href="assets/footer-css.css" media="all" rel="stylesheet" type="text/css">
    <link type="text/css" href="assets/otp.css" rel="stylesheet" media="all">
    <link type="text/css" href="assets/radiobtn.css" rel="stylesheet" media="all">
    <link href="img/favicon.html" rel="shortcut icon" type="image/x-icon">

    <style>
        .ac_footer {
            position: relative;
            text-align: center;
            overflow: hidden;
            padding: 50px 0;
            color: #A12000;
        }

        .ac_footer a {
            color: #A12000;
        }

        .ac_footer p {
            text-align: center;
        }

        img[height="1"],
        img[width="1"] {
            display: none !important;
        }
    </style>
</head>

<body>

    <div class="bottom-call" align="center">
    </div>
    <link href="assets/main.css" rel="stylesheet">
    <link href="assets/media.css" rel="stylesheet">
    <title> Hammer of Thor </title>
    <div class="wrapper">
        <section class="present">
            <div class="glare">
                <span class="glare__item glare__item_01 glare__slow"></span>
                <span class="glare__item glare__item_02 glare__fast"></span>
            </div>
            <div class="container container_logo-mod" style="margin-top:50px;">
                <div class="logo"> Hammer of Thor </div>
                <div class="present__title clr-mod"> हमेशा के लिए और भी बड़ा लिंग प्राप्त करें </div>
                <div class="present__wrap">
                    <div class="present__cell">
                        <div class="present__text"><b> 90% महिलाएं चरमानंद का नाटक करती हैं। </b> यह सब इसलिए है क्योंकि ज्यादातर पुरुषों का लिंग छोटा और ढीला होता है। क्या आप इसके लिए राजी हैं?
                        </div>
                        <ul class="advantage">
                            <li class="advantage__item"> लंबाई में +35% </li>
                            <li class="advantage__item"> मोटाई में +18% </li>
                            <li class="advantage__item"> तुरंत लिंग का खड़ा होना </li>
                            <li class="advantage__item"> मजबूत सहनशक्ति: 3 घंटे तक सेक्स करें </li>
                        </ul>
                    </div>
                    <div class="present__cell">
                        <div class="product">
                            <div class="sale">
                                <div class="sale__wrap">
                                    <span class="sale__text"> सेल </span>
                                    <span class="sale__value">50</span>
                                    <span class="sale_text"> बंद </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <a id="od"></a>
                    <img src="assets/here.gif" style="position: relative;bottom: -58px;z-index: 9;" alt="Buy 2 Get 1 Oil Free" />
                    <form action="" enctype="multipart/form-data" class="form present__form" id="order_form" method="POST">
                        <div class="form__wrap">
                            <div class="form__rows">
                                <div class="middle">
                                    <label>
                                        <input type="radio" name="baddress" value="2M" checked />
                                        <div class="back-end box">
                                            <span>2 Months</br>
                                                <div>₹2490</div>
                                                <p><s>₹4990</s></br>
                                                    50% discount</p>
                                            </span>
                                        </div>
                                    </label>
                                    <label>
                                        <input type="radio" name="baddress" value="1M" />
                                        <div class="front-end box">
                                            <span>1 Month</br>
                                                <div>₹2090</div>
                                                <p><s>₹4190</s></br>
                                                    50% discount</p>
                                            </span>
                                        </div>
                                    </label>
                                </div>
                                <style>
                                    .blinking {
                                        animation: blinkingText 1.2s infinite;
                                    }

                                    @keyframes blinkingText {
                                        0% {
                                            color: #000;
                                        }

                                        49% {
                                            color: #000;
                                        }

                                        60% {
                                            color: transparent;
                                        }

                                        99% {
                                            color: transparent;
                                        }

                                        100% {
                                            color: #000;
                                        }
                                    }
                                </style>
                                <div class="form__title blinking"> फॉर्म भरें और हमारा ऑपरेटर ऑर्डर की पुष्टि करने के लिए आपसे संपर्क करेगा 2 घंटे मैं।</div>
                                <div class="form__field nam-num-grp">
                                    <input class="input" id="namee" name="userName" placeholder="नाम" type="text" value="" autocomplete="off" required />
                                </div>
                                <div class="form__field nam-num-grp">
                                    <label for="phone">+91</label>
                                    <input class="input  only only_number phone-input" onkeyup="onMobileChange()" id="phone" name="subject" placeholder="फोन" value="" autocomplete="off" required min="10" maxlength="13" type="text" />
                                </div>
                                <div class="form__field nam-num-grp">
                                    <input class="input" id="address" name="userEmail" placeholder="पता लिखना" type="text" value="" autocomplete="off" required />
                                </div>

                                <button name="send" value=" अभी ऑर्डर करें " type="submit" id="very-btn" class="vryfy-btn">Submit</button>

                            </div>
                            <!-- <button  type="button" class="button__text full-btn js_submit" id="myBtn1" onclick="verify_otp()"> ऑर्डर करें </button> -->
                        </div>
                    </form>

                </div>
            </div>
    </div>
    </section>
    <section class="statistic">
        <div class="container">
            <div class="subtitle subtitle_mod"> अपने सेक्स को <span class="clr-mod"> नॉन स्टॉप परमानंद </span> में बदलें!
            </div>

            <div class="statistic__photo">
                <img src="assets/gifLing.gif">
            </div>
            <div class="statistic__wrap">
                <div class="subtitle subtitle_l-mod"> यदि कोई पुरुष अपनी स्त्री को संतुष्ट नहीं कर सकता है, तो वह अन्य पुरुषों द्वारा संतुष्ट की जाएगी
                </div>
                <div class="statistic__text"> 76% महिलाएं अपने पति को धोखा देकर बेवफाई करती हैं क्योंकि वे सेक्स में असंतुष्ट हैं
                </div>
            </div>
        </div>
    </section>
    <section class="promo">
        <span class="glare__item glare__item_03 glare__slow"></span>
        <div class="container">
            <div class="subtitle"> पुरुष स्वास्थ्य विशेषज्ञों की राय <span class="clr-mod"> अब </span></div>
            <div class="statistic__photo">
                <img src="assets/animated_photo.jpg">
            </div>


            <div class="experts__item-text">
                <p> बहुत कम लोग असली आँकड़ों के बारे में जानते हैं क्योंकि लिंग सर्जरी एक वर्जित मुद्दा है जिसकी खुलेआम बात नहीं की जाती है। मध्य पूर्व में 10,000 से अधिक पुरुष, हर साल सर्जरी कराके अपने लिंग का साइज़ और लंबाई बढ़ाते हैं। हम हमेशा चेतावनी
                    देते हैं कि ये पुरुष सर्जरी कराके गंभीर स्वास्थ्य जोखिम उठा रहे हैं, क्योंकि तंत्रिका तंतुओं का एक नेटवर्क पेनाइल कैविटीस के द्वारा प्रवेश करता है। जब ये कैविटीस क्षतिग्रस्त हो जाती हैं, तो समस्याओं का खतरा बढ़ जाता है, जिसमें उत्तेजनाओं
                    की कमी, लिंग के खड़े होने में दर्द और बांझपन शामिल हैं।
                </p>
                <p> सर्जरी की तुलना में,
                    <span> Hammer of Thor </span> से कोई भी गंभीर दुष्प्रभाव नहीं होते है। यह शरीर को उत्तेजित करके, लिंग में वसा ऊतक को प्राकृतिक रुप से इकठ्ठा कराता है।
                </p>
            </div>



            <div class="statistic__photo">
                <img src="assets/Img2.jpg">
            </div>
            <div class="experts__item-text">
                <p> योनि का सबसे संवेदनशील हिस्सा 2-3 सेमी गहराई में होता है। इसलिए लिंग का साइज़ महिला की इच्छा को संतुष्ट करने में ख़ास भूमिका निभाता है, न कि लंबाई, जैसे हर कोई सोचता है। आपका लिंग जितना बड़ा और कड़ा होगा, आपकी पत्नी उतनी ही ज्यादा संतुष्ट
                    होंगी। <span></span>
                </p>
                <p> इससे भी ज्यादा, एक बड़ा लिंग संभोग के दौरान क्लाइटोरिस को आसानी से उत्तेजित करता है, इस प्रकार चरमानंद की भावना और प्रभाव को कई गुना बढ़ाता है।
                </p>
            </div>

        </div>
    </section>
    <section class="composition">
        <span class="glare__item glare__item_04 glare__fast"></span>
        <div class="container">
            <br>
            <div class="title title_p-mod"><span class="clr-mod"> Hammer of Thor </span> एक लिंग बढ़ाने का एक त्रिस्तरीय फार्मूला है!
            </div>
            <div class="composition__wrap">
                <div class="composition__cell composition__item_01">
                    <div class="composition__title"> आवश्यक तेल </div>
                    <div class="composition__text">
                        <span> लिंग को मजबूती से खड़ा करता है। एक स्पष्ट उत्तेजना और उत्तेजक प्रभाव पाईये। </span> इन घटकों से आप उत्तेजित हो जाएंगे और 30 सेकंड से कम समय में ही सेक्स के लिए तैयार होंगे।
                    </div>
                </div>
                <div class="composition__cell composition__item_02">
                    <div class="composition__title"> सूक्ष्म तत्वों का मिश्रण </div>
                    <div class="composition__text">
                        <span> कमर के अंगों में खून के वहाव को बढाकर, यौन इच्छा को बढ़ाता है। </span> शुक्राणुओं की क्वालिटी और संख्या में सुधार करता है।
                    </div>
                </div>
                <div class="composition__cell composition__item_03">
                    <div class="composition__title"> सक्रिय पेक्टिन </div>
                    <div class="composition__text"> पुरुष अंग के ऊतकों का निर्माण करके, इसकी लम्बाई और मोटाई को बढाता है।
                        <span> इनकी बदौलत लिंग दोनों सामान्य और उत्तेजित अवस्था में बड़ा हो जाता है। </span>
                    </div>
                </div>
            </div>
            <button class="pre_toform">
                <span class="button__wrap">
                    <span class="button__text"> <a href="#od">ऑर्डर करें </a> </span>
                </span>
            </button>
        </div>
    </section>
    <section class="effect">
        <div class="container">
            <div class="subtitle subtitle_w-mod clr-mod_03"> Hammer of Thor
                <span class="clr-mod_02"> का इस्तेमाल करने के बाद नतीजे </span>
            </div>
            <div class="effect__subwrap">
                <div class="effect__arrow"></div>
                <div class="effect__wrap">
                    <div class="effect__cell">
                        <div class="effect__pict">
                            <img loading="lazy" src="assets/dick_01.png">
                        </div>
                        <div class="effect__data">
                            <div class="effect__parameter"> लंबाई <span> + 1.3 सेमी </span></div>
                            <div class="effect__parameter"> मोटाई <span> + 0.5 सेमी </span></div>
                        </div>
                    </div>
                    <div class="effect__cell effect__cell_mob">
                        <div class="effect__pict">
                            <img loading="lazy" src="assets/dick_02.png">
                        </div>
                        <div class="effect__data">
                            <div class="effect__parameter"> लंबाई <span> + 2.5 सेमी </span></div>
                            <div class="effect__parameter"> मोटाई <span> +1.2 सेमी </span></div>
                        </div>
                    </div>
                    <div class="effect__cell effect__cell_mob">
                        <div class="effect__pict">
                            <img loading="lazy" src="assets/dick_03.png">
                        </div>
                        <div class="effect__data">
                            <div class="effect__parameter"> लंबाई <span> + 3.2 सेमी </span></div>
                            <div class="effect__parameter"> मोटाई <span> +1.9 सेमी </span></div>
                        </div>
                    </div>
                    <div class="effect__cell">
                        <div class="effect__pict effect__pict_mod">
                            <img loading="lazy" src="assets/dick_04.png">
                        </div>
                        <div class="effect__data">
                            <div class="effect__parameter"> लंबाई <span> +4.7 सेमी </span></div>
                            <div class="effect__parameter"> मोटाई <span> +2.6 सेमी </span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="use">
        <span class="glare__item glare__item_05 glare__fast"></span>
        <div class="container">
            <div class="title title_mob"><span class="clr-mod"> Hammer of Thor </span> इस्तेमाल करने में आसान है </div>
            <div class="use__slider">
                <div class="use__wrap">
                    <div class="use__cell use__item_01">
                    </div>
                    <br><br>
                    <div class="slider__item">
                        <div class="user__data">
                            <div class="user__info" style="text-align: center;"><span class="user__name"> रोजाना एक कैप्सूल लीजिये</span></div>
                            <div class="review__text" style="text-align: center;"> दवा के सक्रिय तत्व लिंग की कैवर्नस बॉडीज को प्रभावित करके, इसकी लंबाई और मात्रा में बढ़ाते हैं।
                            </div>
                        </div>
                    </div>
                    <div class="use__cell use__item_02">
                    </div>
                </div>
                <br><br>
                <div class="slider__item">
                    <div class="user__data">
                        <div class="user__info" style="text-align: center;"><span class="user__name"> सेक्स से पहले एक अतिरिक्त कैप्सूल लें</span></div>
                        <div class="review__text" style="text-align: center;"> दवा उत्तेजना बढ़ाती है और लिंग में खून के बहाव को बढाती है। लिंग लम्बे समय तक खड़ा रहता है, और सेक्स 3 घंटे तक चलेगा।
                        </div>
                    </div>
                </div>
                <div class="use__cell use__item_03">
                </div>
            </div>
            <br><br>
            <div class="slider__item">
                <div class="user__data">
                    <div class="user__info" style="text-align: center;"><span class="user__name"> अपने आप को कम मत आंकिये </span></div>
                    <div class="review__text" style="text-align: center;"> आप जितना ज्यादा सेक्स करेंगे, आपका लिंग उतना ही ज्यादा उत्तेजित होगा और आपका लिंग मजबूती से खड़ा होगा।
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    <section class="review">
        <div class="container">
            <div class="title"> ग्राहकों के रिव्यु </div>
            <div class="review__slider slider">
                <div class="slider__item">
                    <div class="user user_01">
                        <div class="user__data">
                            <div class="user__info"><span class="user__name"> अनन्या </span> , <span class="user__age">35</span></div>
                            <div class="review__text"> मेरे पति और मुझे बिस्तर में कोई गंभीर समस्या नहीं थी, लेकिन उनके लिंग का साइज़ मुझे पूरी तरह से संतुष्ट करने के लिए काफी छोटा था। मुझे उसका साइज़ भी काफी नहीं लगा। हालाँकि मैंने इसे अपने पास राज़ रखा। मुझे लगा कि यह ख़ास नहीं
                                था। फिर मैंने Hammer of Thor का ऑनलाइन रिव्यु देखा और इसे अपने पति के लिए ऑर्डर किया। भगवान, यह इस तरह से बहुत बढ़िया है!
                            </div>
                        </div>
                    </div>
                </div>
                <div class="slider__item">
                    <div class="user user_02">
                        <div class="user__data">
                            <div class="user__info"><span class="user__name"> अर्जुन </span> , <span class="user__age">28</span></div>
                            <div class="review__text"> मेरा पहला यौन अनुभव बहुत अच्छा नहीं था। अपनी जवानी से ही, मैंने अपने छोटे लिंग को लेकर असुरक्षित महसूस किया। मैंने 18 साल की उम्र में अपनी वर्जिनिटी खो दी थी। हताश होकर, मैं ऑनलाइन गया और Hammer of Thor के बहुत सारे अच्छे रिव्यु
                                मिले, इसलिए मैंने एक डिब्बा खरीदा। मैंने अपनी अगली मुलाकात से पहले इसका इस्तेमाल किया। हमने रात भर शानदार सेक्स किया!!! मैंने पहली बार ऐसा कुछ अनुभव किया था। मैं अब Hammer of Thor का कोर्स ले रहा हूं। केवल 2 सप्ताह में,
                                मेरा लिंग 3 सेमी बड़ा हो गया!
                            </div>
                        </div>
                    </div>
                </div>
                <div class="slider__item">
                    <div class="user user_03">
                        <div class="user__data">
                            <div class="user__info"><span class="user__name"> आरव </span> , <span class="user__age">47</span></div>
                            <div class="review__text"> यह सच में आपके लिंग के साइज़ को बढाता है! मैंने कई सारी चीजें, पंप, क्रीम और गोलियां आजमायीं थीं। इनमें से किसी ने भी असर नहीं किया। मेरी पत्नी बहुत स्मार्ट है, उसे Hammer of Thor मिला। मैंने एक आजमाईश के लिए इसे खरीदा था।
                                मैंने उसके मार्गदर्शन में इसका इस्तेमाल किया। मैंने कैप्सूल का इस्तेमाल जारी रखने का फैसला लिया है। यह मुझे 100% संतुष्ट करता है! हम फिर से युवाओं की तरह बहुत बढ़िया सेक्स करते हैं। हम बहुत खुश है।
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="order">
        <div class="glare">
            <span class="glare__item glare__item_06 glare__fast"></span>
            <span class="glare__item glare__item_07 glare__slow"></span>
            <span class="glare__item glare__item_08 glare__slow"></span>
        </div>
        <div class="container">
            <div class="title title_order-mob subtitle_w-mod"><span class="clr-mod"> Hammer of Thor </span> बिस्तर में आपकी सफलता की पक्की गारंटी है!
            </div>
            <div class="order__wrap">
                <div class="order__cell">
                    <div class="product product__order">
                        <div class="sale sale__order">
                            <div class="sale__wrap">
                                <span class="sale__text"> सेल </span>
                                <span class="sale__value">50</span>
                                <span class="sale_text"> बंद </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="order__cell">

                </div>
            </div>
            <button class="pre_toform btm-btn-ord left-100">
                <span class="button__wrap">
                    <span class="button__text"> <a href="#od"> ऑर्डर करें </a> </span>
                </span>
            </button>
        </div>
    </section>
    </div>

    <div class="ac_footer">
        <span>© 2022 Copyright. All rights reserved.</span><br>
        <a href="#" target="_blank">Privacy policy</a> | <a href="#">Report</a>
        <p>The results may vary depending on your individual features<br>आपके सोर्स डाटा और निजी गुण-धर्मों के आधार पर नतीजे अलग-अलग हो सकते हैं </p>
    </div>

</body>

</html>
<?php
if (!empty($message)) {
?>
    <p class='<?php echo $type; ?>Message'>
        <?php
        echo '<script language="javascript">';
        echo 'window.location = "db.php";';
        echo '</script>';
        ?>
    </p>
<?php
}
?>